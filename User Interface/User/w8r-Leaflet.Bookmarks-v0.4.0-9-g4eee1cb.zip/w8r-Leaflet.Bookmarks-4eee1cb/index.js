import L from 'leaflet';
import Bookmarks from './src/bookmarks';

L.Control.Bookmarks = Bookmarks;

export default Bookmarks;
